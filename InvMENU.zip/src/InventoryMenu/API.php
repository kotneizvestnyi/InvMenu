<?php

declare(strict_types=1);

namespace InventoryMenu;


use InventoryMenu\event\InventoryClickEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\BlockEntityDataPacket;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\network\mcpe\protocol\ContainerOpenPacket;
use pocketmine\network\mcpe\protocol\ContainerSetContentPacket;
use pocketmine\network\mcpe\protocol\DropItemPacket;
use pocketmine\network\mcpe\protocol\ContainerSetSlotPacket;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class API extends PluginBase implements Listener
{
    /** @var  array */
    private $chest, $inv;
    /** @var  API */
    public static $instance;

    public function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onLoad(): void
    {
        self::$instance = $this;
    }

    /**
     * @return API
     */
    public static function getInstance(): API
    {
        return self::$instance;
    }

    public function onDataPacketReceive(DataPacketReceiveEvent $e): void
    {
        $packet = $e->getPacket();
        $player = $e->getPlayer();
        if ($packet instanceof ContainerSetSlotPacket) {
            if (!isset($this->chest[$player->getName()])) return;
            if ($packet->windowid == 10 && $this->chest[$player->getName()] && $packet->item->getId() == 0) {
                $pk = new ContainerClosePacket();
                $pk->windowid = 10;
                $player->dataPacket($pk);
                $this->getServer()->getPluginManager()->callEvent($ev = new InventoryClickEvent($this, $player, $packet->slot, $this->chest[$player->getName()][0]));
            }
        } elseif ($packet instanceof ContainerClosePacket) {
            if (!isset($this->chest[$player->getName()]) or !isset($this->inv[$player->getName()])) return;
            /** @var Vector3 $v3 */
            $v3 = $this->chest[$player->getName()][1];
            $this->updateBlock($player, $player->getLevel()->getBlock($v3)->getId(), $v3);
            $this->clearData($player);
        } elseif ($packet instanceof DropItemPacket) {
            if (!isset($this->chest[$player->getName()])) return;
            $e->setCancelled();
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $e): void
    {
        $this->clearData($e->getPlayer());
    }

    public function createChest(Player $player, array $items, int $id, string $title): void
    {
        $this->clearData($player);
        $this->inv[$player->getName()] = $player->getInventory()->getContents();
        $v3 = $this->getVector($player);
        $this->chest[$player->getName()] = [$id, $v3];
        $this->updateBlock($player, 54, $v3);

        $nbt = new NBT(NBT::LITTLE_ENDIAN);
        $nbt->setData($title === "" ? new CompoundTag("", []) : new CompoundTag("", [new StringTag("CustomName", $title)]));

        $pak = new BlockEntityDataPacket;
        $pak->x = (int) $v3->x;
        $pak->y = (int) $v3->y;
        $pak->z = (int) $v3->z;
        $pak->namedtag = $nbt->write(true);
        $player->dataPacket($pak);

        $pk = new ContainerOpenPacket;
        $pk->windowid = 10;
        $pk->type = 0;
        $pk->x = (int) $v3->x;
        $pk->y = (int) $v3->y;
        $pk->z = (int) $v3->z;
        $player->dataPacket($pk);
        $pk1 = new ContainerSetContentPacket;
        $pk1->windowid = 10;
        $pk1->slots = $items;
        $pk1->targetEid = $id;
        $player->dataPacket($pk1);
    }
    public function updateBlock(Player $player, int $id, Vector3 $v3): void {
        $pk = new UpdateBlockPacket;
        $pk->x = (int) $v3->x;
        $pk->y = (int) $v3->y;
        $pk->z = (int) $v3->z;
        $pk->blockId = $id;
        $pk->blockData = (int) 0xb << 4 | (0 & 0xf);
        $player->dataPacket($pk);
    }
    public function getVector(Player $player): Vector3
    {
        return new Vector3($player->x, $player->y - 3, $player->z);
    }
    public function clearData(Player $player): void
    {
        if (isset($this->chest[$player->getName()]))
            unset($this->chest[$player->getName()]);
        if (isset($this->inv[$player->getName()]))
            unset($this->inv[$player->getName()]);
    }
}